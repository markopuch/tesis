^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package abb
^^^^^^^^^^^^^^^^^^^^^^^^^

1.3.1 (2019-09-17)
------------------
* Update maintainers (`#139 <https://github.com/ros-industrial/abb/issues/139>`_)
* Contributors: gavanderhoorn

1.3.0 (2017-05-27)
------------------
* Added 4400 support package to meta-package manifest of abb.
* fix comments from PR `#126 <https://github.com/ros-industrial/abb/issues/126>`_.
* kinetic-devel release of ros-industrial/abb
* Contributors: AustinDeric, Jonathan Meyer

1.2.1 (2017-03-27)
------------------
* No changes

1.2.0 (2015-06-06)
------------------
* Remove deprecated package abb_moveit_plugins
* Contributors: Levi Armstrong

1.1.9 (2015-04-07)
------------------
* Remove dependencies from package.xml for removed deprecated packages
* Removed deprecated package abb_moveit_plugins
* Contributors: Levi Armstrong

1.1.8 (2015-04-06)
------------------
* No changes

1.1.7 (2015-04-01)
------------------
* Merged hydro branch
  - Updated CHANGELOG.rst and package.xml files
* Removed deprecated packages
  - abb_common
  - irb_2400_moveit_config
  - irb_6640_moveit_config
* Contributors: Levi Armstrong

1.1.6 (2015-03-17)
------------------
* No changes

1.1.5 (2015-03-17)
------------------
* No changes

1.1.4 (2014-12-14)
------------------
* Merged release artifacts from hydro branch
* meta: update description.
* Contributors: Shaun Edwards, gavanderhoorn

1.1.3 (2014-09-05)
------------------
* Merged changes from hydro (release) branch.  Changes include only release artifacts
* meta: add IRB 2400 & 6640 MoveIt configs and plugin pkgs.
* meta: add new IRB support packages (2400, 5400 & 6600).
* driver: move driver (Rapid and nodes) into separate package.
  Node sources, headers and launch files copied from abb_common.
* Contributors: Shaun Edwards, gavanderhoorn

1.1.2 (2014-06-07)
------------------
* No changes

1.1.1 (2014-05-27)
------------------
* Updated abb packages to Catkin
* Fixed minor issues with MoveIt configurations (updates from groovy to hydro)
* Removed arm navigation
* added metapackage subdirectory
  git-svn-id: https://swri-ros-pkg.googlecode.com/svn/branches/catkin_migration@1411 076cdf4d-ed99-c8c1-5d01-9bc0d27e81bd
* Contributors: Shaun Edwards, jrgnicho
