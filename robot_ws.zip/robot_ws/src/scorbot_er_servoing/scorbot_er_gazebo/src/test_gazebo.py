#!/usr/bin/env python3
import time
import roslib
import rospy
import actionlib
from control_msgs.msg import *
from trajectory_msgs.msg import *
from markers import *
from functions import *
from ar_track_alvar_msgs.msg import AlvarMarker


if __name__ == '__main__':
    
    rospy.init_node("test_gazebo", disable_signals=True)

    robot_client = actionlib.SimpleActionClient('/scorbot_er/scorbot_er_joint_controller/follow_joint_trajectory', FollowJointTrajectoryAction)

    print ("Waiting for server...")
    robot_client.wait_for_server()
    print ("Connected to server")

    bmarker = BallMarker(color['RED'])
    bmarker_des = BallMarker(color['GREEN'])

    joint_names = ['base_link__link_01', 'link_01__link_02', 'link_02__link_03', 'link_03__link_04', 'link_04__gripper']
    xd = np.array([0, 0, 0  ])
    # Initial configuration
    Q0 = [0.0, -1.0, -0.72, -1.5708, 0]
    # Q0 = np.array([0, 0, 0, 0, 0])
    # Inverse kinematics
    Q1 = ikine_scorbot(xd, Q0)
    # Q0 = [0.0, -1.0, -0.72, -1.5708, 0]

    # Resulting position (end effector with respect to the base link)
    T = fkine_scorbot(Q0)
    print('Obtained value:\n', np.round(T, 3))
    print(Q1)
    # Red marker shows the achieved position
    bmarker.xyz(T[0:3, 3])
    # Green marker shows the desired position
    bmarker_des.xyz(xd)
    g = FollowJointTrajectoryGoal()
    g.trajectory = JointTrajectory()
    g.trajectory.joint_names = joint_names

    # Initial position
    g.trajectory.points = [ JointTrajectoryPoint(positions=Q0, velocities=[0]*5,time_from_start=rospy.Duration(2.0))]
    robot_client.send_goal(g)
    robot_client.wait_for_result()
    rospy.sleep(1)
    
    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        robot_client.cancel_goal()

        # Modification of the motion
        Q0[0] = Q0[0]

        g.trajectory.points = [ JointTrajectoryPoint(positions=Q0, velocities=[0]*5, time_from_start=rospy.Duration(0.01))]
        robot_client.send_goal(g)
        robot_client.wait_for_result()

        bmarker.publish()
        bmarker_des.publish()
        rate.sleep()

    robot_client.cancel_goal()
